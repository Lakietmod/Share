# File: pro_autosend.py (Đã sửa lỗi gửi video và tăng cường chống lỗi kết nối)

import pytz
import json
import random
import requests
import threading
import time
from datetime import datetime
from zlapi.models import Message, ThreadType
from core.bot_sys import get_user_name_by_id, is_admin, read_settings, write_settings

# Biến toàn cục để đảm bảo thread chỉ khởi động một lần
autosend_thread_started = False

# Dữ liệu thơ theo thời gian
time_poems = {
    "01:00": [
        "🌙✨ Đem khuya vang, giac mo đay, ngu ngon nhe!",
        "🌌💤 Gio lanh ru, long nhe bay, nghi thoi nao!",
        "🌃❄️ 1 gio sang, chan am đay, mo đep nha!",
        "🌜🌠 Trang mo ao, giac mo bay, ngu that sau!",
        "✨🌙 Đem sau lang, mat nham ngay, nghi ngoi nao!",
        "🌌💫 Sao lung linh, đem yen đay, ngu ngon thoi!",
        "🌃🌬️ Khuya tinh lang, giac mo đay, nghi ngoi nhe!",
        "🌙❄️ Đem lanh lam, chan keo đay, mo đep nao!",
        "🌠✨ Trang diu dang, long nhe bay, ngu that sau!",
        "🌜🌌 1 gio roi, đung thuc nua, nghi thoi nha!",
        "✨💤 Đem yen binh, giac mo đay, ngu ngon nhe!",
        "🌙🌠 Gio khuya lanh, mat nham đay, nghi ngoi thoi!",
        "🌌❄️ Đem sau tham, chan am bay, mo đep nha!",
        "🌃✨ Khuya vang ve, long nhe đay, ngu that sau!",
        "🌜💫 Trang lang le, giac mo đay, nghi ngoi nao!"
    ],
    "02:30": [
        "🌙🌌 Khuya lanh lam, giac mo đay, ngu ngon nhe!",
        "🌃✨ Đem sau lang, chan keo ngay, nghi thoi nao!",
        "🌜💤 Gio khuya ru, long nhe bay, mo đep nha!",
        "🌠❄️ 2 ruoi sang, mat nham đay, ngu that sau!",
        "✨🌙 Đem tinh lang, giac mo bay, nghi ngoi thoi!",
        "🌌💫 Sao lap lanh, chan am đay, ngu ngon nao!",
        "🌃🌬️ Khuya yen binh, giac mo đay, nghi ngoi nhe!",
        "🌙❄️ Đem sau tham, long nhe bay, mo đep thoi!",
        "🌠✨ Trang mo ao, giac mo đay, ngu that sau!",
        "🌜🌌 2 gio hon, đung thuc nua, nghi ngoi nha!",
        "✨💤 Đem lanh lam, chan keo đay, ngu ngon nhe!",
        "🌙🌠 Gio hat ru, giac mo bay, nghi thoi nao!",
        "🌌❄️ Khuya tinh lang, mat nham đay, mo đep nha!",
        "🌃✨ Đem sau lang, long nhe đay, ngu that sau!"
    ],
    "04:00": [
        "🌃🌙 Đem khuya lanh, giac mo đay, ngu ngon nhe!",
        "🌜✨ 4 gio sang, chan am bay, nghi thoi nao!",
        "🌌💤 Gio lanh ru, long nhe đay, mo đep nha!",
        "🌠❄️ Đem tinh lang, mat nham ngay, ngu that sau!",
        "✨🌙 Trang mo ao, giac mo bay, nghi ngoi thoi!",
        "🌃💫 Sao lung linh, chan keo đay, ngu ngon nao!",
        "🌙🌬️ Khuya yen binh, giac mo đay, nghi ngoi nhe!",
        "🌌❄️ Đem sau tham, long nhe bay, mo đep thoi!",
        "🌠✨ Trang lang le, giac mo đay, ngu that sau!",
        "🌜🌌 4 gio roi, đung thuc nua, nghi ngoi nha!",
        "✨💤 Đem lanh lam, chan am đay, ngu ngon nhe!",
        "🌙🌠 Gio khuya ru, giac mo bay, nghi thoi nao!",
        "🌌❄️ Khuya tinh lang, mat nham đay, mo đep nha!",
        "🌃✨ Đem sau lang, long nhe đay, ngu that sau!"
    ],
    "05:30": [
        "🌅☀️ Binh minh gan, giac mo đay, day thoi nao!",
        "☀️✨ Sang nhe nhang, nang luong bay, chao ngay nhe!",
        "🌞💫 5 ruoi sang, long hang say, khoi đau thoi!",
        "🌻❀ Nang ban mai, giac mo đay, day that nhanh!",
        "✨🌅 Sang tuoi moi, tinh than bay, chao buoi sang!",
        "☀️🌬️ Gio mat lanh, nang luong đay, bat đau nao!",
        "🌞🌈 Binh minh rang, giac mo bay, day đi thoi!",
        "🌅💤 Sang lung linh, long nhe đay, chao ngay nhe!",
        "☀️🌻 Nang diu dang, tinh than bay, khoi đau thoi!",
        "✨🌞 5 gio hon, ngay moi đay, day that nhanh!",
        "🌅❀ Sang ruc ro, giac mo đay, chao buoi sang!",
        "☀️🌬️ Nang ban mai, long hang say, bat đau nao!",
        "🌞💫 Sang tuoi đep, nang luong bay, day đi nhe!",
        "🌻✨ Gio mat sang, giac mo đay, chao ngay thoi!"
    ],
    "07:00": [
        "🌞☀️ Sang ruc ro, ngay moi đay, day thoi nao!",
        "☀️✨ 7 gio sang, nang lung lay, chao buoi sang!",
        "🌅💫 Mot ngay moi, long hang say, bat đau thoi!",
        "🌻❀ Nang ban mai, giac mo đay, day that nhanh!",
        "✨🌞 Sang tuoi đep, nang luong bay, chao ngay moi!",
        "☀️🌬️ Gio mat lanh, tinh than đay, khoi đau nao!",
        "🌞🌈 Binh minh rang, giac mo bay, day đi thoi!",
        "🌅💤 Sang lung linh, long nhe đay, chao ngay nhe!",
        "☀️🌻 Nang diu dang, tinh than bay, bat đau thoi!",
        "✨🌞 7 gio roi, ngay moi đay, day that nhanh!",
        "🌅❀ Sang ruc ro, giac mo đay, chao buoi sang!",
        "☀️🌬️ Nang ban mai, long hang say, bat đau nao!",
        "🌞💫 Sang tuoi đep, nang luong bay, day đi nhe!",
        "🌻✨ Gio mat sang, giac mo đay, chao ngay thoi!"
    ],
    "08:30": [
        "🌞☕ Sang hieu qua, cong viec đay, co len nao!",
        "☕✨ 8 ruoi sang, tinh than bay, lam viec thoi!",
        "🌻💫 Nang ban mai, nang luong đay, bat đau nhe!",
        "✨🌞 Sang ruc ro, long hang say, lam that tot!",
        "☀️🌬️ Gio mat lanh, giac mo bay, hieu qua nao!",
        "🌅❀ Nang diu dang, tinh than đay, lam viec thoi!",
        "🌞🌈 8 gio hon, cong viec đay, co len nhe!",
        "☕💤 Sang tuoi moi, long nhe bay, lam that nhanh!",
        "✨🌻 Nang lung linh, nang luong đay, hieu qua thoi!",
        "☀️🌞 Sang yen binh, giac mo đay, lam viec nao!",
        "🌅💫 Gio mat sang, tinh than bay, co len thoi!",
        "🌞❀ Nang ban mai, long hang say, lam that tot!",
        "☕✨ Sang ruc ro, cong viec đay, hieu qua nao!"
    ],
    "10:00": [
        "🌞⏰ 10 gio sang, nang luong đay, lam viec nao!",
        "☀️✨ Nang ruc ro, tinh than bay, co len nhe!",
        "🌻💫 Sang tuoi moi, giac mo đay, hieu qua thoi!",
        "✨🌞 Gio mat lanh, long hang say, lam that tot!",
        "☕❀ Nang diu dang, cong viec đay, bat đau nao!",
        "🌅🌈 10 gio roi, tinh than bay, lam viec thoi!",
        "🌞💤 Sang lung linh, nang luong đay, co len nhe!",
        "☀️🌻 Nang ban mai, giac mo bay, hieu qua nao!",
        "✨⏰ Sang yen binh, long nhe đay, lam that nhanh!",
        "🌞❀ Gio mat sang, tinh than đay, lam viec thoi!",
        "☕💫 Nang ruc ro, cong viec bay, co len nao!",
        "🌅✨ Sang tuoi đep, nang luong đay, hieu qua thoi!"
    ],
    "10:57": [
        "🌞🍽️ Gan trua roi, nghi ngoi đay, an ngon nhe!",
        "☀️✨ 11 ruoi sang, giac mo bay, nghi thoi nao!",
        "🌻💤 Nang ban trua, long nhe đay, thu gian thoi!",
        "✨⏰ Trua yen binh, nang luong đay, an that ngon!",
        "☕❀ Gio mat lanh, tinh than bay, nghi ngoi nao!",
        "🌅🌈 Nang diu dang, giac mo đay, an ngon nhe!",
        "🌞💫 11 gio hon, bung đoi đay, nghi thoi nao!",
        "☀️🌻 Trua ruc ro, mon ngon bay, thu gian thoi!",
        "✨🍽️ Nang ban trua, long hang say, an that ngon!",
        "🌞❀ Gio mat trua, giac mo đay, nghi ngoi nao!"
    ],
    "13:00": [
        "🌞⏰ 1 gio chieu, nang luong đay, lam viec nao!",
        "☀️✨ Nang ruc ro, tinh than bay, co len nhe!",
        "🌻💫 Chieu tuoi moi, giac mo đay, hieu qua thoi!",
        "✨🌞 Gio mat lanh, long hang say, lam that tot!",
        "☕❀ Nang diu dang, cong viec đay, bat đau nao!",
        "🌅🌈 1 gio roi, tinh than bay, lam viec thoi!",
        "🌞💤 Chieu lung linh, nang luong đay, co len nhe!",
        "☀️🌻 Nang ban chieu, giac mo bay, hieu qua nao!",
        "✨⏰ Chieu yen binh, long nhe đay, lam that nhanh!"
    ],
    "14:30": [
        "🌞🌻 Chieu lang man, giac mo đay, vui ve nao!",
        "☀️✨ 2 ruoi chieu, tinh than bay, lam viec nhe!",
        "🌅💫 Nang diu dang, nang luong đay, co len thoi!",
        "✨⏰ Chieu ruc ro, long hang say, hieu qua nao!",
        "☕❀ Gio mat lanh, giac mo bay, lam that tot!",
        "🌞🌈 Nang ban chieu, tinh than đay, bat đau nao!",
        "🌻💤 Chieu yen binh, cong viec bay, co len nhe!"
    ],
    "16:00": [
        "🌅✨ Chieu dan troi, giac mo đay, thu gian nao!",
        "☀️🌻 4 gio chieu, tinh than bay, nghi ngoi nhe!",
        "🌞💫 Nang nhat dan, nang luong đay, lam viec thoi!",
        "✨⏰ Chieu yen binh, long hang say, hieu qua nao!",
        "☕❀ Gio mat chieu, giac mo bay, co len nhe!",
        "🌅🌈 Nang diu dang, tinh than đay, lam that tot!"
    ],
    "17:30": [
        "🌅🌞 Hoang hon gan, giac mo đay, nghi ngoi nao!",
        "☀️✨ 5 ruoi chieu, tinh than bay, thu gian nhe!",
        "🌻💤 Nang nhat dan, long nhe đay, nghi thoi nao!",
        "✨⏰ Chieu ta đen, nang luong bay, thu gian thoi!",
        "☕❀ Gio mat lanh, giac mo đay, nghi ngoi nhe!"
    ],
    "19:30": [
        "🌙✨ Toi diu dang, giac mo đay, an ngon nao!",
        "🌌💤 7 gio toi, tinh than bay, nghi ngoi nhe!",
        "🌜❄️ Đem yen binh, mon ngon đay, thu gian thoi!",
        "✨🍽️ Toi ruc ro, long hang say, an that ngon!",
        "☕🌙 Gio mat đem, giac mo bay, nghi ngoi nao!"
    ],
    "20:30": [
        "🌙✨ Sap ngu roi, giac mo đay, ngu ngon nao!",
        "🌌💤 8 ruoi toi, chan keo bay, nghi thoi nhe!",
        "🌜❄️ Đem yen tinh, long nhe đay, mo đep thoi!",
        "✨⏰ Toi diu dang, tinh than bay, ngu that sau!",
        "☕🌙 Gio mat đem, giac mo đay, nghi ngoi nao!"
    ],
    "22:06": [
        "🌙🌌 Đem khuya đen, giac mo đay, ngu ngon nao!",
        "🌃✨ 10 gio toi, chan am bay, nghi thoi nhe!",
        "🌜💤 Gio lanh ru, long nhe đay, mo đep thoi!",
        "✨⏰ Đem yen binh, tinh than bay, ngu that sau!",
        "☕🌙 Trang lang le, giac mo đay, nghi ngoi nao!"
    ],
    "23:30": [
        "🌙✨ Khuya lam roi, giac mo đay, ngu ngon nao!",
        "🌌💤 11 ruoi toi, chan keo bay, nghi thoi nhe!",
        "🌜❄️ Đem tinh lang, long nhe đay, mo đep thoi!",
        "✨⏰ Gio khuya ru, tinh than bay, ngu that sau!",
        "☕🌙 Trang mo ao, giac mo đay, nghi ngoi nao!"
    ],
    "00:00": [
        "🌙🌌 Nua đem roi, giac mo đay, ngu ngon nao!",
        "🌃✨ 12 gio khuya, chan am bay, nghi thoi nhe!",
        "🌜💤 Gio lanh ru, long nhe đay, mo đep thoi!",
        "✨⏰ Đem sau tham, tinh than bay, ngu that sau!",
        "☕🌙 Trang lang le, giac mo đay, nghi ngoi nao!"
    ]
}

def get_random_video_url():
    try:
        list_url = "https://raw.githubusercontent.com/Lakietmod/Vdautosend1/refs/heads/main/autosend1.json"
        headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'}
        response = requests.get(list_url, headers=headers, timeout=15)
        response.raise_for_status()
        video_urls = response.json()
        return random.choice(video_urls) if video_urls else None
    except requests.exceptions.RequestException as e:
        print(f"❌ Lỗi mạng khi lấy danh sách video: {e}")
        return None
    except json.JSONDecodeError as e:
        print(f"❌ Lỗi file JSON video: {e}")
        return None

def autosend_task(client):
    vn_tz = pytz.timezone('Asia/Ho_Chi_Minh')
    MESSAGE_TTL = 2700000 
    while True:
        try:
            now = datetime.now(vn_tz)
            current_time_str = now.strftime("%H:%M")
            if current_time_str in time_poems:
                settings = read_settings(client.uid)
                autosend_groups = {k: v for k, v in settings.get("autosend", {}).items() if v} # Chỉ lấy nhóm đang bật

                if not autosend_groups:
                    time.sleep(20)
                    continue

                video_url = get_random_video_url()
                
                for thread_id, enabled in autosend_groups.items():
                    # Gửi video với cơ chế thử lại
                    if video_url:
                        max_retries = 3
                        for attempt in range(max_retries):
                            try:
                                client.sendRemoteVideo(
                                    videoUrl=video_url,
                                    thumbnailUrl="https://f66-zpg-r.zdn.vn/jxl/8107149848477004187/d08a4d364d8cf9d2a09d.jxl",
                                    duration=0,
                                    thread_id=thread_id,
                                    thread_type=ThreadType.GROUP,
                                    ttl=MESSAGE_TTL
                                )
                                print(f"✅ Đã gửi video tự xóa đến nhóm {thread_id}")
                                break  # Thoát khỏi vòng lặp nếu gửi thành công
                            except Exception as e:
                                print(f"❌ Lỗi gửi video lần {attempt + 1}/{max_retries} đến nhóm {thread_id}: {e}")
                                if attempt < max_retries - 1:
                                    time.sleep(3) # Chờ 3 giây trước khi thử lại
                                else:
                                    print(f"❌ Không thể gửi video đến nhóm {thread_id} sau {max_retries} lần thử.")
                        time.sleep(1)

                    # Gửi thơ
                    try:
                        poem = random.choice(time_poems[current_time_str])
                        bot_name = get_user_name_by_id(client, client.uid)
                        text_message_content = f"🚦{poem}\n🚦{current_time_str} - Bot: {bot_name} Autosend"
                        client.sendMessage(Message(text=text_message_content), thread_id=thread_id, thread_type=ThreadType.GROUP, ttl=MESSAGE_TTL)
                        print(f"✅ Đã gửi thơ tự xóa đến nhóm {thread_id}")
                    except Exception as e:
                        print(f"❌ Lỗi khi gửi tin nhắn thơ đến nhóm {thread_id}: {e}")
                    
                    time.sleep(5) # Khoảng nghỉ giữa các nhóm
                
                time.sleep(61) # Chờ đến phút tiếp theo
            else:
                time.sleep(20) # Kiểm tra lại sau 20 giây
        except Exception as task_error:
            print(f"❌ Lỗi nghiêm trọng trong autosend_task: {task_error}")
            time.sleep(60)

def handle_autosend_command(client, message_object, thread_id, thread_type, message, prefix, author_id):
    global autosend_thread_started
    if not autosend_thread_started:
        # Khởi động luồng nền autosend nếu chưa có
        threading.Thread(target=autosend_task, args=(client,), daemon=True).start()
        autosend_thread_started = True
        print(f"✅ Tiến trình Autosend cho bot {client.me_name} đã được khởi chạy lần đầu.")

    if not is_admin(client, author_id):
        client.replyMessage(Message(text="❌ Bạn không phải admin bot!"), message_object, thread_id=thread_id, thread_type=thread_type)
        return

    command = message.replace(f"{prefix}autosend", "").strip().lower()
    settings = read_settings(client.uid)
    
    if "autosend" not in settings:
        settings["autosend"] = {}

    current_status = settings.get("autosend", {}).get(thread_id, False)

    if command == "on":
        if current_status:
            client.replyMessage(Message(text=f"⚠️ Tính năng autosend đã được bật từ trước trong nhóm này."), message_object, thread_id=thread_id, thread_type=thread_type)
        else:
            settings["autosend"][thread_id] = True
            write_settings(client.uid, settings)
            client.replyMessage(Message(text=f"✅ Đã bật tính năng autosend cho nhóm này."), message_object, thread_id=thread_id, thread_type=thread_type)
    elif command == "off":
        if not current_status:
            client.replyMessage(Message(text=f"⚠️ Tính năng autosend vốn đã tắt trong nhóm này."), message_object, thread_id=thread_id, thread_type=thread_type)
        else:
            settings["autosend"][thread_id] = False
            write_settings(client.uid, settings)
            client.replyMessage(Message(text=f"⭕ Đã tắt tính năng autosend cho nhóm này."), message_object, thread_id=thread_id, thread_type=thread_type)
